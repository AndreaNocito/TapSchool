/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trasferimento_file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.ObjectOutputStream;

/**
 *
 * @author andre
 */
public class client {
    final static String path = "C:/Users/andre/Downloads/wallpapers/13.jpg";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // String serverAddress = JOptionPane.showInputDialog( "Enter IP Address of a machine that is\n" +"running the date service on port 9090:");
        String serverAddress = "192.168.1.43";
        Socket s = new Socket(serverAddress, 3339);
        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
        //String answer = input.readLine();
        //JOptionPane.showMessageDialog(null, answer);
        File f;
        f = new File(path);
        ObjectOutputStream o = new ObjectOutputStream(s.getOutputStream());
        o.reset();
        o.writeObject(f);
        o.flush();
        o.close();
        System.exit(0);
    }

}
