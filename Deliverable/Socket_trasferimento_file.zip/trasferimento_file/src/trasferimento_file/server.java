/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trasferimento_file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author andre
 */
public class server {

    private static final String SAVE_DIR = "";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        ServerSocket listener = new ServerSocket(3339);
        try {
            while (true) {
                Socket socket = listener.accept();
                try {
                    ObjectInputStream oIN = new ObjectInputStream(socket.getInputStream());
                    File fIN = (File) oIN.readObject();

                    File saveFile = new File(SAVE_DIR + "/"+ fIN.getName());
                    save(fIN, saveFile);

                } catch (Exception ex) {
                    System.err.println(ex);
                } finally {
                    socket.close();
                }
            }
        } finally {
            listener.close();
        }

    }

    private static void save(File in, File out) throws IOException {
        System.out.println("Ricezione file: "+ in.getName()+" - "+in.length());
        FileInputStream fI = new FileInputStream(in);
        FileOutputStream fO = new FileOutputStream(out);
        byte[] buf = new byte[1024];
        int i=0;
        while((i=fI.read(buf))!=-1) {
            fO.write(buf,0,i);
        }
        fI.close();
        fO.close();
        System.out.println("File ricevuto");
    }

}
