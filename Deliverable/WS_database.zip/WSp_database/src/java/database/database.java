/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author andre
 */
@WebService(serviceName = "database")
public class database {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName = "eseguiQuery")
    public String eseguiQuery(@WebParam(name = "query") String query) {
        String JDBC_DRIVER = "com.myqls.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost";
        System.out.println("hello");
        String user = "root", pass = "";
        Connection conn = null;
        Statement stmt = null;
        try {
            //Class.forName(JDBC_DRIVER);
            
            System.out.println("Mi connetto al database selezionato");
            
            conn = DriverManager.getConnection(DB_URL, user,pass);
            System.out.println("Connessione al database riuscita");
            
            System.out.println("Creo statement");
            stmt = conn.createStatement();
            
            System.out.println("|Eseguo la query: " + query);
            ResultSet rs = stmt.executeQuery(query);
            return rs.toString();
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        return("ader");
        }
    }
}
