/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsc_database;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author andre
 */
public class WSc_database {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // System.out.println(hello("Chandler"));
      System.out.println(eseguiQuery("CREATE DATABASE db1 IF NOT EXISTS"));
       

    
}

    private static String eseguiQuery(java.lang.String query) {
        database.Database_Service service = new database.Database_Service();
        database.Database port = service.getDatabasePort();
        return port.eseguiQuery(query);
    }
}
