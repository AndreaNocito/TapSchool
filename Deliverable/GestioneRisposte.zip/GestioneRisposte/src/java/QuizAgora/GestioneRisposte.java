/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QuizAgora;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Giada
 */
@WebService(serviceName = "GestioneRisposte")
public class GestioneRisposte {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getRisposta")
    public String getRisposta(@WebParam(name = "nomeUtente") String nomeUtente, @WebParam(name = "chiave") String chiave, @WebParam(name = "idDomanda") String idDomanda, @WebParam(name = "risposta") String risposta) {
        //TODO write your implementation code here:
        //String tot=nomeUtente+";"+chiave+";"+idDomanda+";"+risposta;
        
        String ricevi = "SELECT Id FROM Studenti WHERE (idUtente='" + nomeUtente+ "')";    //Ricevere l'id dello studente che risponde alla domanda
        
        //Prendi IDStudente
        String idUtente="";
        
        String query = "INSERT INTO Risposta ('id', 'testo', 'idUtente', 'idDomanda') VALUES ('" +risposta + "'," + idUtente + "," + idDomanda +")";  //Inserimento delle risposte nel database
    /**
     * Web service operation
     */
  
    //per gestire la risposta in modo ottimale, attendere lo sviluppo del database
    
    /**
     * This is a sample web service operation
     */
    
    
    
}
