/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModificaProfiloStudente;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Giada
 */
@WebService(serviceName = "Modifica")
public class Modifica {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "setDati")
    public String setDati(@WebParam(name = "nome") String nome, @WebParam(name = "cognome") String cognome, @WebParam(name = "nomeUtente") String nomeUtente, @WebParam(name = "password") String password, @WebParam(name = "email") String email, @WebParam(name = "tipo") final String tipo) throws FileNotFoundException {
        //TODO write your implementation code here:
        // Modifico i dati
        String file;
        switch(tipo){
            case "studente": file="studenti.csv";
            break;
        }
        BufferedReader br;
        br = null;
        String line = "";
        String cvsSplitBy = ";";
        String mess = "Dati non trovati";
        List<String> lines = new ArrayList();
        try {

            br = new BufferedReader(new FileReader(file));
            
            while ((line = br.readLine()) != null) {
                // use ; as separator
                String[] dati = line.split(cvsSplitBy);
                if(nomeUtente.equals(dati[2]))
                {
                    mess="Dati modificati";
                    line=nome+cvsSplitBy+cognome+cvsSplitBy+nomeUtente+cvsSplitBy+password+cvsSplitBy+email+cvsSplitBy+tipo;
                }
                lines.add(line);

            }
            
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }  finally {
                if (br != null) {
                    try {
                        br.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        }
        PrintWriter pw = new PrintWriter(file);
                   
        for(String s:lines) {
            pw.write(s+"\r\n");
        }
        pw.close();
        return mess;
    }
}
