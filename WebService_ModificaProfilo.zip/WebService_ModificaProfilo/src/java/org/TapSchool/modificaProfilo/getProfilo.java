/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.TapSchool.modificaProfilo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author andreanocito
 */
@WebService(serviceName = "getProfilo")
public class getProfilo {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "setDati")
    public String setDati(@WebParam(name = "nome") String nome, @WebParam(name = "cognome") String cognome, @WebParam(name = "nomeUtente") String nomeUtente, @WebParam(name = "password") String password, @WebParam(name = "email") String email, @WebParam(name = "tipo") final String tipo) {
        //TODO write your implementation code here:
        // Modifico i dati
        return null;
    }
}
